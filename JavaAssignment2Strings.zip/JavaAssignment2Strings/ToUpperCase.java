import java.util.Scanner;

public class ToUpperCase {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        String s1 = sc.nextLine();
        String s1upper=s1.toUpperCase();
        System.out.println(s1upper);
    }
}
//this is java
//THIS IS JAVA
