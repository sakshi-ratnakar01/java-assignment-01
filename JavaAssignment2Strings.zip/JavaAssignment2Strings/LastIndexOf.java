public class LastIndexOf {
    public static void main(String args[]){
        String s1="this is index of example";//there are 2 's' characters
        int index1=s1.lastIndexOf('s');//returns last index of 's' char value
        System.out.println(index1);//6
    }
}
