

public class ContainsExample {
    public static void main(String[] args) {
        String str = "To learn Java visit Javatpoint.com";
        if(str.contains("Javatpoint.com")) {
            System.out.println("This string contains javatpoint.com");
        }else
            System.out.println("Result not found");
    }
}

//Output

//This string contains javatpoint.com